from fastapi import FastAPI, WebSocket, WebSocketDisconnect, Request, Depends, HTTPException
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from fastapi.middleware.cors import CORSMiddleware
from pathlib import Path
import json
import uvicorn
import asyncio
import os

# Папки и файлы
BASE_DIR = Path(__file__).resolve().parent
CONFIG_FILE = BASE_DIR / "../bot/config.json"
LOG_FILE = BASE_DIR / "../bot/bot.json"

app = FastAPI(title="Discord Bot Admin Panel")

# Разрешенные источники
origins = [
    "*",  # Поменяй на конкретный адрес на продакшене
]

app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ============================
# STATIC FILES (Frontend)
# ============================
app.mount("/static", StaticFiles(directory="static"), name="static")

# ============================
# ROUTES - HTML FRONTEND
# ============================
@app.get("/", response_class=HTMLResponse)
async def main_page():
    html_path = BASE_DIR / "templates/index.html"
    with open(html_path, encoding="utf-8") as f:
        return f.read()

# ============================
# API ENDPOINTS
# ============================
@app.get("/api/config")
async def get_config():
    with open(CONFIG_FILE, "r", encoding="utf-8") as f:
        data = json.load(f)
    return JSONResponse(content=data)

@app.post("/api/config")
async def update_config(request: Request):
    try:
        data = await request.json()
        with open(CONFIG_FILE, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=4, ensure_ascii=False)
        return {"status": "success", "message": "Config updated"}
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

@app.get("/api/logs")
async def get_logs():
    if not LOG_FILE.exists():
        return JSONResponse(content={"logs": ["No log file found."]})
    with open(LOG_FILE, "r", encoding="utf-8") as f:
        logs = f.read().splitlines()[-100:]  # Последние 100 строк
    return JSONResponse(content={"logs": logs})

# ============================
# WEBSOCKETS FOR LIVE LOGS
# ============================
connected_websockets = []

@app.websocket("/ws/logs")
async def websocket_logs(websocket: WebSocket):
    await websocket.accept()
    connected_websockets.append(websocket)
    try:
        while True:
            await asyncio.sleep(2)
            logs = []
            if LOG_FILE.exists():
                with open(LOG_FILE, "r", encoding="utf-8") as f:
                    logs = f.read().splitlines()[-10:]
            await websocket.send_json({"logs": logs})
    except WebSocketDisconnect:
        connected_websockets.remove(websocket)

# ============================
# MAIN ENTRY POINT
# ============================
if __name__ == "__main__":
    uvicorn.run("app:app", host="0.0.0.0", port=8000, reload=True)
